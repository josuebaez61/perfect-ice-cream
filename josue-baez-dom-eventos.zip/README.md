# PERFECT ICE CREAM

Proyecto final para el curso de Javascript de Coderhouse.

## Visualizar el proyecto

Ejectuar ```npm install``` en la raiz del proyecto para instalar los modulos de node. Y luego ejecutar ``` npm start ``` para visuarlizar el proyecto en un servidor local, por defecto se iniciara en localhost:8080

Y para construir el dist...

```npm run build(:dev)```